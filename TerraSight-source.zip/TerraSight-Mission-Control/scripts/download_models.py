from pathlib import Path
from huggingface_hub import snapshot_download
root=Path(__file__).resolve().parents[1]
for name,repo in [('depth','depth-anything/Depth-Anything-V2-Metric-Outdoor-Small-hf'),('seg','nvidia/segformer-b0-finetuned-ade-512-512')]:
 snapshot_download(repo_id=repo,local_dir=root/'work/models'/name)
