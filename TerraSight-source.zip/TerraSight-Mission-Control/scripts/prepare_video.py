"""Decode a user's own 2:1 video, run real pretrained inference, create a portable local bundle."""
from pathlib import Path
import argparse,json,subprocess,sys,os,base64,hashlib,uuid
import numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates
import imageio_ffmpeg
p=argparse.ArgumentParser();p.add_argument('video',type=Path);p.add_argument('--start',type=float,default=0);p.add_argument('--duration',type=float,default=12);p.add_argument('--fps',type=float,default=5);p.add_argument('--front-yaw',type=float,default=0);a=p.parse_args()
if not 0<a.duration<=60 or not 0<a.fps<=10:raise SystemExit('Use duration up to 60 seconds and FPS up to 10.')
source_video=a.video.resolve();root=Path(__file__).resolve().parents[1];os.chdir(root);folder=root/'public/user-media'/uuid.uuid4().hex;folder.mkdir(parents=True,exist_ok=True);(root/'work').mkdir(exist_ok=True)
subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-hide_banner','-loglevel','error','-ss',str(a.start),'-i',str(source_video),'-t',str(a.duration),'-vf',f'fps={a.fps},scale=3072:1536','-q:v','2','-y',str(folder/'frame-%05d.jpg')],check=True)
W,H=640,480;y,x=np.mgrid[0:H,0:W];dx=2*(x+.5)/W-1;dy=(1-2*(y+.5)/H)*H/W;pitch=-15*np.pi/180;py=dy*np.cos(pitch)+np.sin(pitch);pz=np.cos(pitch)-dy*np.sin(pitch)
frames=[];samples=[];step=max(1,round(a.fps));paths=sorted(folder.glob('frame-*.jpg'))[:round(a.duration*a.fps)]
if not paths:raise SystemExit('No video frames decoded')
for i,path in enumerate(paths):
 rgb=np.asarray(Image.open(path).convert('RGB'));viewfiles={}
 for name,yaw in [('front',0),('left',-90),('right',90),('rear',180)]:
  heading=(yaw+a.front_yaw)*np.pi/180;px=dx*np.cos(heading)+pz*np.sin(heading);zz=pz*np.cos(heading)-dx*np.sin(heading);u=(np.arctan2(px,zz)/(2*np.pi)+.5)%1*rgb.shape[1];v=np.clip((.5-np.arctan2(py,np.hypot(px,zz))/np.pi)*rgb.shape[0],0,rgb.shape[0]-1);out=np.stack([map_coordinates(rgb[:,:,c],[v,u],order=1,mode='wrap') for c in range(3)],-1).astype(np.uint8);dest=folder/f'camera-{i:05d}-{name}.jpg';Image.fromarray(out).save(dest,quality=92);viewfiles[name]=str(dest.relative_to(root/'public'))
 key=f'user{i//step*step:05d}';frames.append({'index':i,'timeS':round(i/a.fps,5),'sourceTimeS':round(a.start+i/a.fps,5),'pano':str(path.relative_to(root/'public')),'views':viewfiles,'analysisId':key})
 if i%step==0:samples.append({'id':key,'file':str(path.relative_to(root/'public')),'frontYawDegrees':a.front_yaw})
manifest=root/'work/video-samples.json';manifest.write_text(json.dumps({'samples':samples}));env=os.environ.copy();env['TERRASIGHT_MANIFEST']=str(manifest);subprocess.run([sys.executable,str(root/'processing/process_images.py')],env=env,check=True)
def uri(relative):
 path=root/'public'/relative;return 'data:image/'+('jpeg' if path.suffix=='.jpg' else 'png')+';base64,'+base64.b64encode(path.read_bytes()).decode()
analyses={}
for f in frames:
 key=f['analysisId']
 if key not in analyses:
  d=json.loads((root/'public/processed'/f'{key}.json').read_text())
  for v in d['views']:
   for field in ['rgb','semantics','depth','confidence']:v[field]=uri(v[field])
  analyses[key]=d
 f['pano']=uri(f['pano']);f['views']={k:uri(v) for k,v in f['views'].items()}
bundle={'title':'User-provided video','frameIntervalS':1/a.fps,'durationS':len(frames)/a.fps,'sourceClip':[a.start,a.start+a.duration],'frontYawDegrees':a.front_yaw,'frames':frames,'analyses':analyses,'poseGroundTruth':None,'sourceVideoSHA256':hashlib.file_digest(source_video.open('rb'),'sha256').hexdigest(),'limitations':['User-declared video pairing','No measured pose','Camera height prior 1.5 m','Monocular geometry estimates']}
output=root/'work/analysis-bundle.json';output.write_text(json.dumps(bundle,separators=(',',':')));print('Load in the web app:',output)
