'use strict';
// Perspective projection of the estimated DSM/DTM, with camera pose on the chosen route.
let driveMode='recorded';
$('driveViewButtons').insertAdjacentHTML('beforebegin','<div id="driveMode" class="mapControls"><button data-mode="recorded" class="primary">Source view</button><button data-mode="geometry">3D route simulation</button></div>');
$('immersiveWrap').insertAdjacentHTML('afterend','<canvas id="routePerspective" width="960" height="540" aria-label="Three dimensional route simulation from estimated terrain geometry" hidden></canvas>');
const routeCanvas=$('routePerspective'),routeContext=routeCanvas.getContext('2d');
function drawRoutePerspective(){
 if(driveMode!=='geometry'||!processed)return;
 const ctx=routeContext,w=routeCanvas.width,h=routeCanvas.height,n=data.gridSize,r=data.resolutionM,p=pathPose(),heading=pathHeading()+lookYaw;
 const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#214554');bg.addColorStop(.55,'#7fa2a4');bg.addColorStop(.56,'#18282a');bg.addColorStop(1,'#101b20');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
 const c=Math.cos(heading),s=Math.sin(heading),pitch=-.12,cp=Math.cos(pitch),sp=Math.sin(pitch),f=w/2;
 function projection(v){const x=v[0]-p.x,y=v[1]-p.y,z=v[2]-p.z,xx=x*c-z*s,zz=x*s+z*c,yy=y*cp-zz*sp,depth=zz*cp+y*sp;if(depth<.08)return null;return {x:w/2+xx/depth*f,y:h/2-yy/depth*f,z:depth};}
 const polys=[];
 function face(points,color){const vs=points.map(projection);if(vs.some(v=>!v))return;polys.push({vs,color,z:vs.reduce((t,v)=>t+v.z,0)/vs.length});}
 const colors={0:'#3498c5',1:'#a5926b',2:'#977c75',3:'#718589',4:'#43864c',5:'#809345'};
 for(const cell of data.cells){if(cell.dtm===null)continue;const x=cell.x*r-data.extentM/2,z=data.extentM/2-cell.y*r,y=cell.dtm;
  face([[x,y,z],[x+r,y,z],[x+r,y,z-r],[x,y,z-r]],colors[cell.semantic]||'#9a8d69');
  const height=cell.ndsm??0;if(height>.25&&cell.semantic!==1&&cell.semantic!==5){const top=y+Math.min(height,6),color=cell.semantic===4?'#356b42':'#71676a';face([[x,top,z],[x+r,top,z],[x+r,top,z-r],[x,top,z-r]],color);face([[x,y,z],[x+r,y,z],[x+r,top,z],[x,top,z]],color);face([[x,y,z-r],[x+r,y,z-r],[x+r,top,z-r],[x,top,z-r]],color);face([[x,y,z],[x,y,z-r],[x,top,z-r],[x,top,z]],color);face([[x+r,y,z],[x+r,y,z-r],[x+r,top,z-r],[x+r,top,z]],color);}
 }
 polys.sort((a,b)=>b.z-a.z);for(const poly of polys){ctx.globalAlpha=Math.max(.25,1-poly.z/50);ctx.fillStyle=poly.color;ctx.beginPath();poly.vs.forEach((v,i)=>i?ctx.lineTo(v.x,v.y):ctx.moveTo(v.x,v.y));ctx.closePath();ctx.fill();ctx.strokeStyle='#13252c33';ctx.lineWidth=.5;ctx.stroke();}ctx.globalAlpha=1;
 ctx.lineWidth=5;ctx.strokeStyle='#6af2bd';let previous=null;for(const id of route.slice(Math.floor(progress))){const cell=data.cells[id],v=projection([(cell.x+.5)*r-data.extentM/2,(cell.dtm??0)+.04,data.extentM/2-(cell.y+.5)*r]);if(v&&previous){ctx.beginPath();ctx.moveTo(previous.x,previous.y);ctx.lineTo(v.x,v.y);ctx.stroke();}previous=v;}
 ctx.fillStyle='#101e27df';ctx.fillRect(12,h-62,w-24,50);ctx.fillStyle='#e1f5ef';ctx.font='17px system-ui';ctx.fillText('Image-derived 3D terrain · camera follows selected A → B route',25,h-38);ctx.font='13px system-ui';ctx.fillText('Monocular elevation estimates. Gaps are unobserved. Blocks represent surface height, not object models.',25,h-17);
}
function applyDriveMode(){const geometry=driveMode==='geometry';$('cameraPose').textContent=geometry?'A → B · '+Math.round(sequenceIndex/Math.max(1,seq.frames.length-1)*100)+'% simulated progress':'Recorded frame '+(sequenceIndex+1)+'/'+seq.frames.length+' · '+seq.frames[sequenceIndex].timeS.toFixed(1)+' s';$('playbackPanel').querySelector('p').textContent=geometry?'3D camera and map marker follow the same selected A → B route. Geometry is estimated from the input images; surfaces and confidence stay fixed.':seq.staticExample?'Licensed static image. Upload your own 360° video for recorded playback. Route motion is available in the 3D simulation.':'Recorded scene follows its captured trajectory, not arbitrary planned map branches.';$('routePerspective').hidden=!geometry;$('routePerspective').style.display=geometry?'block':'none';$('immersiveWrap').hidden=geometry||!lookGL;for(const b of $('driveMode').querySelectorAll('button'))b.classList.toggle('primary',b.dataset.mode===driveMode);drawRoutePerspective();}
for(const button of $('driveMode').querySelectorAll('button'))button.onclick=()=>{driveMode=button.dataset.mode;applyDriveMode();};
const perspectiveMarker=paintTraversalMarker;paintTraversalMarker=function(fraction){progress=fraction*Math.max(0,route.length-1);perspectiveMarker(fraction);drawRoutePerspective();if(driveMode==='geometry')$('cameraPose').textContent='A → B · '+Math.round(fraction*100)+'% simulated progress';};
for(const button of $('driveViewButtons').querySelectorAll('button')){const previous=button.onclick;button.onclick=()=>{previous();drawRoutePerspective();};}
const perspectiveLoad=load;load=function(i){perspectiveLoad(i);driveMode='recorded';progress=0;applyDriveMode();};$('capture').onchange=()=>load(+$('capture').value);
const perspectiveProcess=$('process').onclick;$('process').onclick=()=>{perspectiveProcess();progress=0;applyDriveMode();};
$('routePerspective').style.display='none';

const perspectiveReport=report;report=function(){return {...perspectiveReport(),splitView:{mode:driveMode,normalizedProgress:sequenceIndex/Math.max(1,seq.frames.length-1),geometryCameraPose:pathPose(),geometryCameraHeading:pathHeading()+lookYaw,geometryCameraFollowsPlannedRoute:true,recordedCameraPoseMeasured:false}};};
