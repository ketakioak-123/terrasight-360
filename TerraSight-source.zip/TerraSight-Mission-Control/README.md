# TerraSight 360 — Mission Control

A separate clone of the original prototype, rebuilt around the supplied 13-screen mission-control specification. The original prototype is unchanged.

## Quick start

Requires Node 18+ and Python 3.11+. No npm packages or frontend build step are required.

```sh
npm test
npm start
```

Open http://localhost:8080. Click **40-second guided demo** to walk through all 13 modes. The example uses a licensed real panorama from Changali Wala, Punjab, with real precomputed pretrained-model inference. It is a static capture, not recorded vehicle travel.

## GitHub + deployment

1. Create an empty GitHub repository named `terrasight-mission-control` (no initial README).
2. Open a terminal in this extracted directory:

```sh
git init -b main
git add .
git commit -m "Add TerraSight mission-control prototype"
git remote add origin https://github.com/YOUR_USERNAME/terrasight-mission-control.git
git push -u origin main
```

3. In GitHub: **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. Run **Actions → Deploy TerraSight Mission Control → Run workflow**, or push another commit. The workflow tests the app, uploads `public/`, then publishes to Pages.
5. The workflow's deployment environment shows the final URL, normally `https://YOUR_USERNAME.github.io/terrasight-mission-control/`.

No live deployment has been performed by this package. A repository and authenticated push are still required. All asset paths are relative, so repository subpaths work without configuration. Instructions follow [GitHub's custom Pages workflow documentation](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

## Upload your own 360° video

Click **Upload 360° video** and choose a browser-compatible equirectangular (2:1) H.264 MP4 or WebM. It is decoded locally and never uploaded to a server. Front / left / right / rear buttons select directions in the same video instant. Play/pause controls the uploaded video.

**Raw video alone does not produce terrain inference.** Until a matching analysis bundle is loaded, the app marks terrain unknown and disables meaningful route planning. It does not reuse the example's predictions on new footage.

For actual inference on your own video:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/download_models.py
python scripts/prepare_video.py /absolute/path/to/your-video.mp4 --start 0 --duration 12 --fps 5 --front-yaw 0
```

This downloads SegFormer B0 ADE20K and Depth Anything V2 Metric Outdoor Small, decodes real source frames, computes the existing four-view perception pipeline, and writes `work/analysis-bundle.json`. In the app, select the video and click **Load analysis bundle** for that exact source. Use `--front-yaw` to manually choose a road-facing panorama heading if needed. Generated files are excluded by `.gitignore`.

The bundle identifies the source with a SHA-256 digest, but browser pairing remains user-declared. Uploading a bundle for another video is invalid. The source clip offset is respected. The raw video has no measured pose, so recorded imagery cannot establish that a robot actually followed an arbitrary planned route. **3D route simulation** instead moves a perspective camera through the selected route on the estimated terrain.

## Included screens

1. Mission control: surrounding source / segmentation / depth / confidence, terrain layers, route, decision.
2. Explainable cells: geometry, approximate projected RGB VDVI, confidence, capability constraints and rejection reasons.
3. Vehicle profile: mini/large presets and editable dimensions, ground clearance, wheel radius, slope, side tilt, step, margin and safe drop; Apply recalculates.
4. Same terrain, different vehicle: footprint-aware maps and computed restriction percentages. Unknown is separate and causes may overlap.
5. Linked DSM / DTM / object-height inspection.
6. Simulated overhead beam and vertical vehicle-envelope cross-section.
7. Synthetic short grass / tall grass / dense bush feature cases.
8. Simulated ditch with a declared 0.62 m drop.
9. Simulated crossing pedestrian, current/+1/+2 second positions, occupancy and replanning.
10. Simulated full-sensor / vision-only trajectories; measured odometry, drift and loop closures remain unimplemented.
11. Deterministic heartbeat fault injection with emergency stop and reason code.
12. Research metrics remain **Not measured**. Engineering checks are separate from accuracy/safety benchmarks.
13. Indian terrain evidence cards and actual baseline segmentation. Laterite geology, category labels and India-adapted models are not verified/trained.

## Technical limits

- DSM/DTM, object height, slope and roughness are monocular estimates with a 1.5 m camera-height prior, not surveys.
- Confidence is a stated evidence heuristic, not calibrated safety probability.
- The capture/vehicle origin is at grid centre. Route A is snapped to nearby observed feasible ground; the initial gap is not a verified driveable connector.
- Ground under occlusion is unknown. DSM−DTM is object height, not free overhead clearance.
- Actual overhead free space, side tilt, visual odometry, obstacle tracking and localization are not measured here. Their dedicated demos are labelled simulations or unavailable.
- Underbody clearance uses a ground-residual/vegetation proxy. Wheel radius is profile metadata and does not independently infer traction or wheel contact.
- 3D route simulation is coarse estimated terrain geometry, not a photorealistic digital twin.
- Vehicle comparison statistics use the same grid and all 2,304 cells; they are computed results, not the document's example percentages.
- The guided tour visits screens; it does not claim benchmark experiments have been performed.

## Project structure

- `public/` — deployment-ready static app, source modules, licensed examples and inference.
- `public/mission-control.js` — all 13 mission-control modes, vehicle constraints and labelled scenarios.
- `public/uploads.js` — browser-local video and portable analysis bundle inputs.
- `public/terrain.js` — estimated geometry, constraint evaluation and graph routing.
- `public/route3d.js` — perspective camera simulation along the selected route.
- `scripts/` and `processing/` — optional real video/model preprocessing.
- `tests/validate.mjs` — syntax, assets and meaningful constraint tests.
- `.github/workflows/pages.yml` — test and publish `public/` to GitHub Pages.
- `ATTRIBUTION.md` — image/model provenance and licences.

## Validation

Run `npm test`. Tests check all JavaScript syntax, local asset references, route footprint restrictions, clear/unknown ground, slope and step gates, vehicle-specific overhead clearance, ditch blocking and exclusion of creator-hosted footage from the public package. Browser checks also cover all 13 modes, cell inspection and the heartbeat emergency-stop interaction.

This is a research/demo simulation. It is not validated robot-control software.


## Traversal memory update
The navigation now contains 10 pages. The duplicate Cell explanation, GPS-denied localization, Research/validation and Indian terrain pages have been removed. Mission control has a side-by-side map and front camera, with optional Left, Right and Rear buttons.

Traversal memory uses browser IndexedDB (`TerraSightTraversalMemory`, `traversals` store). Running a simulation saves visited cells, estimated geometry, confidence, vehicle profile, route and completion status. Memory survives reloads on the same origin/browser. User feedback (confirmed clear, slip, blocked) changes soft route costs in the same scene and vehicle profile; it never overrides hard safety gates or treats simulated visits as measured evidence. Different scenes are kept separate; automatic SLAM, map alignment and loop closure are not implemented. Export database downloads the saved experience as JSON. Browser site-data clearing removes local memory; localhost and GitHub Pages have separate databases.

The public example remains a licensed Indian static panorama, not a recording with all requested obstacle classes. Uploaded recorded footage must be paired with its processed analysis bundle. A complete Indian recording with all requested objects has not been verified. Recorded playback follows the filming trajectory; arbitrary selected branches are shown in the labelled 3D geometry simulation.


## India Driving Dataset input
The IDD workspace imports local JPG/PNG front-facing images and matching `*_gtFine_color.png` annotations. Images are ordered naturally by filename and replayed at two frames/second (presentation timing, not measured timestamps). Match names use the original stem before `_leftImg8bit` / `_gtFine_color`. Raw ID masks are not supported: convert using the official label palette. Dataset download and licence acceptance must be completed at https://idd.insaan.iiit.ac.in/dataset/download/. IDD footage is not included or redistributed. This adapter does not compute depth, SLAM, detections or routes from uploaded IDD images. It cannot provide real 360 views.
