# 40-second demo

Use **40-second guided demo** to visit all 13 modes automatically, or use these highlights:

1. Mission control: toggle Raw → Segmentation → Depth → Confidence; toggle terrain layers. This is a licensed static example; load your own video and matched analysis bundle for actual recorded motion.
2. Click an observed coloured cell: explain geometry, confidence and vehicle restrictions. Grey cells correctly report unknown.
3. Vehicle profile: choose mini/large, edit sliders, then **APPLY VEHICLE**.
4. Vehicle comparison: show two computed traversability maps from identical geometry. Do not quote sample percentages from the specification as results.
5. DSM ↔ DTM: hover a cell; DSM minus DTM is the estimated object height.
6. Overhead clearance: choose **Large UGV + 0.25 m margin**. 1.15 + 0.25 = 1.40 m required, exceeding the simulated 1.31 m beam gap.
7. Negative obstacle: inject the declared simulated 0.62 m drop.
8. Dynamic prediction: **Start crossing test**, then **Clear person / reopen**. Tracks are simulated.
9. Safety supervisor: **Lose camera heartbeat** produces **EMERGENCY STOP / CAMERA_HEARTBEAT_TIMEOUT**. Restore before resuming.

Explain the boundary in one sentence: "The image-derived maps are real pretrained inference; dedicated hazard and localization demos are simulations, and unmeasured research metrics remain blank."


## Traversal memory update
The navigation now contains 10 pages. The duplicate Cell explanation, GPS-denied localization, Research/validation and Indian terrain pages have been removed. Mission control has a side-by-side map and front camera, with optional Left, Right and Rear buttons.

Traversal memory uses browser IndexedDB (`TerraSightTraversalMemory`, `traversals` store). Running a simulation saves visited cells, estimated geometry, confidence, vehicle profile, route and completion status. Memory survives reloads on the same origin/browser. User feedback (confirmed clear, slip, blocked) changes soft route costs in the same scene and vehicle profile; it never overrides hard safety gates or treats simulated visits as measured evidence. Different scenes are kept separate; automatic SLAM, map alignment and loop closure are not implemented. Export database downloads the saved experience as JSON. Browser site-data clearing removes local memory; localhost and GitHub Pages have separate databases.

The public example remains a licensed Indian static panorama, not a recording with all requested obstacle classes. Uploaded recorded footage must be paired with its processed analysis bundle. A complete Indian recording with all requested objects has not been verified. Recorded playback follows the filming trajectory; arbitrary selected branches are shown in the labelled 3D geometry simulation.
