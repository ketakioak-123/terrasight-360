"""Reproducible RGB -> pretrained perception -> estimated 2.5D grid.
No invented geometry. Camera height is an explicit scale prior, not ground truth.
"""
import json,math,time,pathlib,hashlib,os
import numpy as np
from PIL import Image
import torch
from transformers import AutoImageProcessor,AutoModelForDepthEstimation,SegformerForSemanticSegmentation
from scipy.ndimage import gaussian_filter,distance_transform_edt
ROOT=pathlib.Path(__file__).resolve().parents[1];OUT=ROOT/'public/processed';OUT.mkdir(exist_ok=True)
MODEL=ROOT/'work/models';device='mps' if torch.backends.mps.is_available() else 'cpu';torch.set_num_threads(4)
print('Inference device:',device,flush=True)
dp=AutoImageProcessor.from_pretrained(MODEL/'depth',local_files_only=True);dm=AutoModelForDepthEstimation.from_pretrained(MODEL/'depth',local_files_only=True).to(device).eval()
sp=AutoImageProcessor.from_pretrained(MODEL/'seg',local_files_only=True);sm=SegformerForSemanticSegmentation.from_pretrained(MODEL/'seg',local_files_only=True).to(device).eval()
labels=sm.config.id2label;ground_ids=[i for i,n in labels.items() if n in ['road','floor','earth','sidewalk','path','sand','grass','field','land']];veg_ids=[i for i,n in labels.items() if n in ['tree','plant','grass','palm','flower']];water_ids=[i for i,n in labels.items() if n in ['water','sea','river','swimming pool','lake']];sky_ids=[i for i,n in labels.items() if n=='sky'];soft_ids=[i for i,n in labels.items() if n in ['grass','field','plant']]
print('Ground labels:',[(i,labels[i]) for i in ground_ids],flush=True)
WW,HH=384,288;N=48;RES=.5;HEIGHT=1.5
def project(pano,yaw):
 y,x=np.mgrid[0:HH,0:WW];dx=(2*(x+.5)/WW-1);dy=(1-2*(y+.5)/HH)*HH/WW;dz=np.ones_like(dx);pitch=-15*math.pi/180
 py=dy*np.cos(pitch)+dz*np.sin(pitch);pz=dz*np.cos(pitch)-dy*np.sin(pitch);a=yaw*math.pi/180;px=dx*np.cos(a)+pz*np.sin(a);zz=pz*np.cos(a)-dx*np.sin(a)
 u=((np.arctan2(px,zz)/(2*np.pi)+.5)%1*pano.shape[1]).astype(int);v=np.clip((.5-np.arctan2(py,np.hypot(px,zz))/np.pi)*pano.shape[0],0,pano.shape[0]-1).astype(int)
 return Image.fromarray(pano[v,u]),(px,py,zz)
def depth(img):
 inp=dp(images=img,return_tensors='pt').to(device)
 with torch.inference_mode():o=dm(**inp).predicted_depth
 return torch.nn.functional.interpolate(o[:,None],(HH,WW),mode='bicubic',align_corners=False)[0,0].cpu().numpy()
def heat(v,lo,hi):
 t=np.clip((v-lo)/(hi-lo+1e-6),0,1);r=np.clip(1.5-np.abs(4*t-3),0,1);g=np.clip(1.5-np.abs(4*t-2),0,1);b=np.clip(1.5-np.abs(4*t-1),0,1);return np.stack([r,g,b],-1)*255
palette=np.array([[53,159,221],[72,190,108],[219,92,90],[103,116,127],[143,202,98],[226,183,90]],dtype=np.uint8)
def group(seg):
 out=np.full_like(seg,2);out[np.isin(seg,ground_ids)]=1;out[np.isin(seg,veg_ids)]=4;out[np.isin(seg,water_ids)]=0;out[np.isin(seg,sky_ids)]=3;out[np.isin(seg,soft_ids)]=5;return out
samples=json.load(open(os.environ.get('TERRASIGHT_MANIFEST',str(ROOT/'public/data/manifest.json'))))['samples'];all_results=[]
for sample in samples:
 t=time.time();sid=sample['id'];pano=np.asarray(Image.open(ROOT/'public'/sample['file']).convert('RGB'));pano=np.roll(pano,-round(pano.shape[1]*sample.get('frontYawDegrees',0)/360),axis=1);views=[];points=[]
 for name,yaw in [('front',0),('left',-90),('right',90),('rear',180)]:
  img,rays=project(pano,yaw);img.save(OUT/f'{sid}-{name}-rgb.jpg',quality=92)
  inp=sp(images=img,return_tensors='pt').to(device)
  with torch.inference_mode():logits=sm(**inp).logits;logits=torch.nn.functional.interpolate(logits,(HH,WW),mode='bilinear',align_corners=False);prob=logits.softmax(dim=1);conf,seg=prob.max(dim=1)
  conf=conf[0].cpu().numpy();seg=seg[0].cpu().numpy();sem=group(seg);z=depth(img);flip=depth(img.transpose(Image.Transpose.FLIP_LEFT_RIGHT))[:,::-1];disagree=np.abs(z-flip)/np.maximum((z+flip)/2,.1);reliability=conf*np.exp(-disagree*3)*.8
  # Estimate scale from visible ground under a 1.5m camera-height prior.
  px,py,pz=rays;ground=np.isin(seg,ground_ids)&(py<-.12)&(conf>.45);below=-py*z;scale=float(HEIGHT/np.median(below[ground])) if ground.sum()>100 else 1.;scale=float(np.clip(scale,.1,5))
  z=z*scale;X=px*z;Y=HEIGHT+py*z;Z=pz*z
  valid=~np.isin(seg,sky_ids)&np.isfinite(z)&(z>.2)&(np.abs(X)<N*RES/2)&(np.abs(Z)<N*RES/2)&(Y<5)&(Y>-3)
  for y in range(0,HH,2):
   for x in range(0,WW,2):
    if valid[y,x]:points.append((X[y,x],Z[y,x],Y[y,x],int(sem[y,x]),float(reliability[y,x]),bool(ground[y,x])))
  Image.fromarray(palette[sem]).save(OUT/f'{sid}-{name}-sem.png');Image.fromarray(heat(z,0,15).astype(np.uint8)).save(OUT/f'{sid}-{name}-depth.png');Image.fromarray(heat(reliability,0,1).astype(np.uint8)).save(OUT/f'{sid}-{name}-confidence.png')
  np.savez_compressed(OUT/f'{sid}-{name}-raw.npz',depth=z,segmentation=seg,semantic_score=conf,depth_flip_disagreement=disagree)
  views.append({'name':name,'yaw':yaw,'pitch':-15,'fov':90,'width':WW,'height':HH,'depthScalePriorFactor':round(scale,4),'meanSemanticScore':round(float(conf.mean()),4),'medianFlipDisagreement':round(float(np.median(disagree)),4),'meanReliability':round(float(reliability.mean()),4),'groundFraction':round(float(np.isin(seg,ground_ids).mean()),4),'depthMedianM':round(float(np.median(z)),3),'classFractions':{labels[int(i)]:round(float((seg==i).mean()),4) for i in np.unique(seg)},'rgb':f'processed/{sid}-{name}-rgb.jpg','semantics':f'processed/{sid}-{name}-sem.png','depth':f'processed/{sid}-{name}-depth.png','confidence':f'processed/{sid}-{name}-confidence.png'})
  print(sid,name,'done',round(time.time()-t,1),'sec',flush=True)
 buckets={}
 for x,z,h,sem,c,g in points:
  ix=int((x+N*RES/2)/RES);iy=int((N*RES/2-z)/RES)
  if 0<=ix<N and 0<=iy<N:buckets.setdefault((iy,ix),[]).append((h,sem,c,g))
 dtm=np.full((N,N),np.nan);dsm=dtm.copy();confidence=np.zeros((N,N));semantic=np.full((N,N),-1);observations=np.zeros((N,N));rough=np.full((N,N),np.nan)
 for (iy,ix),pp in buckets.items():
  p=np.array(pp);groundvals=p[p[:,3]==1,0];dsm[iy,ix]=np.percentile(p[:,0],85);confidence[iy,ix]=np.mean(p[:,2]);observations[iy,ix]=len(p);semantic[iy,ix]=np.bincount(p[:,1].astype(int)).argmax()
  if len(groundvals)>=3:dtm[iy,ix]=np.median(groundvals);rough[iy,ix]=np.std(groundvals)
 known=np.isfinite(dtm);dist,nearest=distance_transform_edt(~known,return_indices=True);filled=(~known)&(dist<=1.5)&(semantic<0);base=dtm.copy();base[filled]=dtm[tuple(nearest[:,filled])];confidence[filled]=confidence[tuple(nearest[:,filled])]*.45;semantic[filled]=1
 mask=np.isfinite(base);smooth=gaussian_filter(np.nan_to_num(base)*mask,1)/np.maximum(gaussian_filter(mask.astype(float),1),1e-8);base[mask]=smooth[mask]
 # Plane residual provides roughness only where observed ground supports it.
 rough[filled]=rough[tuple(nearest[:,filled])];rough=np.where(mask,np.nan_to_num(rough,nan=.12),np.nan)
 slope=np.full((N,N),np.nan);step=slope.copy()
 for y,x in zip(*np.where(mask)):
  vals=[];sx=[];sz=[]
  for dy,dx in [(0,-1),(0,1),(-1,0),(1,0)]:
   yy,xx=y+dy,x+dx
   if 0<=yy<N and 0<=xx<N and mask[yy,xx]:vals.append(abs(base[y,x]-base[yy,xx]));sx.append(dx*RES);sz.append(dy*RES)
  if vals:slope[y,x]=np.degrees(np.arctan(max(vals)/RES));step[y,x]=max(vals)
 ndsm=np.where(mask&np.isfinite(dsm),np.maximum(0,dsm-base),np.nan)
 cells=[]
 for y in range(N):
  for x in range(N):
   def value(a):return round(float(a[y,x]),4) if np.isfinite(a[y,x]) else None
   cells.append({'x':x,'y':y,'dtm':value(base),'dsm':value(dsm),'ndsm':value(ndsm),'slope':value(slope),'roughness':value(rough),'step':value(step),'confidence':round(float(confidence[y,x]),4),'semantic':int(semantic[y,x]),'observations':int(observations[y,x]),'groundInterpolated':bool(filled[y,x])})
 result={'id':sid,'gridSize':N,'resolutionM':RES,'extentM':N*RES,'cameraHeightPriorM':HEIGHT,'origin':[N//2,N//2],'views':views,'cells':cells,'processingSeconds':round(time.time()-t,2),'inferenceDevice':device,'limitations':['Monocular estimates, not measured terrain','Scale constrained by assumed camera height 1.5m','No calibrated pose, temporal mapping or localization','Reliability heuristic not calibrated safety probability','Ground under occlusion remains unknown'],'models':{'depth':'depth-anything/Depth-Anything-V2-Metric-Outdoor-Small-hf','segmentation':'nvidia/segformer-b0-finetuned-ade-512-512'},'semanticGroups':['water','ground','obstacle','sky','vegetation','soft-ground']}
 (OUT/f'{sid}.json').write_text(json.dumps(result,separators=(',',':')));all_results.append(result);print('GRID',sid,'ground cells',int(mask.sum()),'elapsed',result['processingSeconds'],flush=True)
(OUT/'generated-video-inference.js').write_text('window.TERRA_INFERENCE='+json.dumps({r['id']:r for r in all_results},separators=(',',':'))+';')
print('All real-image inference complete.',flush=True)
